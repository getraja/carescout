﻿using System.Collections.Generic;
using System.Data;
using SODA;
using System;
using ProviderLibrary.LogHelper;

namespace ProviderLibrary.DataHelper
{
    public class ExternalData
    {
        public DataTable GetExternalData(string externalUrl, string token, string fileType, string filePath, string fileName)
        {
            try {
                var client = new SodaClient(externalUrl, token);
                var rows = client.GetResource<Dictionary<string, object>>(fileType).GetRows();
                DataTable dt = new DataTable();
                dt.Clear();
                dt.Columns.Add("providerNumber");
                dt.Columns.Add("providerName");
                dt.Columns.Add("providerAddress");
                dt.Columns.Add("providerCity");
                dt.Columns.Add("providerState");
                dt.Columns.Add("providerZip");
                dt.Columns.Add("providerPhone");

                foreach (var row in rows)
                {
                    DataRow dr = dt.NewRow();
                    dr["providerNumber"] = row["federal_provider_number"].ToString();
                    dr["providerName"] = row["provider_name"].ToString();
                    dr["providerAddress"] = row["provider_address"].ToString();
                    dr["providerCity"] = row["provider_city"].ToString();
                    dr["providerState"] = row["provider_state"].ToString();
                    dr["providerZip"] = row["provider_zip_code"].ToString();
                    dr["providerPhone"] = $"{Convert.ToInt64(row["provider_phone_number"].ToString()):(###) ###-####}";
                    dt.Rows.Add(dr);
                }
                return dt;
            }
            catch (Exception ex)
            {
                WriteErrorLog(ex, filePath, fileName);
                return null;
            }
        }

         void WriteErrorLog(Exception ex, string filePath, string fileName)
        {
            try
            {
                ErrorLog errorLog = new ErrorLog();
                errorLog.LogError(ex, filePath, fileName);
            }
            catch
            {
                // ignored
            }
        }

    }
}
