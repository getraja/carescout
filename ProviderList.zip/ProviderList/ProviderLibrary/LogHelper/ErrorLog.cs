﻿using System;
using System.IO;

namespace ProviderLibrary.LogHelper
{
    public class ErrorLog
    {
        public void LogError(Exception ex, string filePath, string fileName)
        {
            try
            {
                Verify(filePath, fileName);
                using (StreamWriter sw = File.AppendText(fileName))
                {
                    sw.WriteLine("===== Error Log =====");
                    sw.WriteLine("===== Start =====" + DateTime.Now);
                    sw.WriteLine("Error Message: " + ex.Message);
                    sw.WriteLine("Stack Trace: " + ex.StackTrace);
                    sw.WriteLine("===== End =====" + DateTime.Now);
                }
            }
            catch
            {
                // ignored
            }
        }

        public void LogError(bool success, string filePath, string fileName, string message)
        {
            try
            {
                Verify(filePath, fileName);
                using (StreamWriter sw = File.AppendText(fileName))
                {
                    sw.WriteLine("===== Error Log =====");
                    sw.WriteLine("===== Start =====" + DateTime.Now);
                    sw.WriteLine("Message: " + message);
                    sw.WriteLine("===== End =====" + DateTime.Now);
                }
            }
            catch
            {
                // ignored
            }
        }

        private static void Verify(string filePath, string fileName)
        {
            try
            {
                DirectoryInfo directory = new DirectoryInfo(filePath);
                if (!directory.Exists)
                {
                    Directory.CreateDirectory(filePath);
                }

                if (!File.Exists(fileName))
                {
                    File.Create(fileName).Dispose();
                }
            }
            catch
            {
                // ignored
            }
        }

        //public static void ReadError(string filePath)
        //{
        //    using (StreamReader sr = new StreamReader(filePath))
        //    {
        //        string line;
        //        while ((line = sr.ReadLine()) != null)
        //        {
        //            Console.WriteLine(line);
        //        }
        //    }
        //}
    }
}
