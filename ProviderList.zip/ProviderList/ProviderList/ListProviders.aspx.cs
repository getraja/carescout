﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using ProviderLibrary.DataHelper; // for data retrieval
using ProviderLibrary.LogHelper; // for error logging
using System.IO;
using System.Web.UI;

namespace ProviderList
{
    public partial class ListProviders : System.Web.UI.Page
    {
        #region Global Variables
        string filePath, fileName, externalUrl, token, providerType = string.Empty;
        #endregion

        #region Page Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            // get info from the web.config
            GetConfigFileInfo(ref filePath, ref fileName, ref externalUrl, ref token, ref providerType); // Methods for page load event region

            if (!IsPostBack || Cache["Provider"] == null) // if first time or the cached object doesn't exist, then get the external data
            {
                InitializeSessionVariables();
                ImportProviderData(); // get external data region
                PopulateGrid(1, 15); // methods for GridView region
            }
        }


        #endregion

        #region Methods for Page load event
        private void GetConfigFileInfo(ref string filePath, ref string fileName, ref string externalUrl, ref string token, ref string fileType)
        {
            try
            {
                this.filePath = ConfigurationManager.AppSettings["ErrorLogDirectory"];
                this.fileName = ConfigurationManager.AppSettings["ProviderListErrorFile"];
                this.externalUrl = ConfigurationManager.AppSettings["ExternalUrl"];
                this.token = ConfigurationManager.AppSettings["Token"];
                this.providerType = ConfigurationManager.AppSettings["ProviderType"];

            }
            catch { }
        }
        private void InitializeSessionVariables()
        {
            Session["sortText"] = "providerNumber ASC";
            Session["currentPageNumber"] = "1";
        }
        #endregion

        #region Get external Data
        private void ImportProviderData()
        {
            try
            {
                DataTable dt = new DataTable();
                ExternalData externalData = new ExternalData();
                dt = externalData.GetExternalData(externalUrl, token, providerType, filePath, fileName); // Provider Library Data Helper
                Cache["Provider"] = dt; // cache the datatable for subsequent use
            }
            catch (Exception ex)
            {
                WriteErrorLog(ex, filePath, fileName);
            }

        }
        #endregion

        #region GridView Events
        protected void GvProvider_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                SortDirection sDirection = SortDirection.Ascending;
                string sField = string.Empty;

                GetSortColumnAndDirection(gvProvider, e); // get selected column for sorting and sorting direction - Methods for Gridview region

                string strSortDirection = sDirection == SortDirection.Ascending ? "ASC" : "DESC";

                PopulateGrid(int.Parse(Session["currentPageNumber"].ToString()), int.Parse(ddlPageRows.SelectedValue.ToString())); // Methods for GridView region
            }
            catch (Exception ex)
            {
                WriteErrorLog(ex, filePath, fileName);  // Method for Error Logging region
            }

        }
        #endregion

        #region Methods for GridView
        private void GetSortColumnAndDirection(GridView gv, GridViewSortEventArgs e) // get selected colum and sorting order
        {
            try
            {
                string sField = e.SortExpression;
                SortDirection sDirection = e.SortDirection;

                if (gv.Attributes["CurrentSortField"] != null && gv.Attributes["CurrentSortDirection"] != null)
                {

                    if (sField == gv.Attributes["CurrentSortField"])
                    {
                        if (gv.Attributes["CurrentSortDirection"] == "ASC")
                        {
                            sDirection = SortDirection.Descending;
                        }
                        else
                        {
                            sDirection = SortDirection.Ascending;
                        }
                    }
                    gv.Attributes["CurrentSortField"] = sField;
                    gv.Attributes["CurrentSortDirection"] = (sDirection == SortDirection.Ascending ? "ASC" : "DESC");
                    string strSortDirection = sDirection == SortDirection.Ascending ? "ASC" : "DESC";

                    // store the selected column for sort and the sort direction in the session varaible for  a 
                    Session["sorttext"] = sField + " " + strSortDirection;
                }
            }
            catch (Exception ex)
            {
                WriteErrorLog(ex, filePath, fileName); // Method in Error Logging region
            }

        }

        private void PopulateGrid(int pageNumber, int pageSize)
        {
            try
            {
                DataTable dt = (DataTable)Cache["Provider"];

                if (txtProviderNumber.Text.Trim() != string.Empty)
                {
                    dt = dt.Select("providerNumber like '%" + txtProviderNumber.Text + "%'").CopyToDataTable(); //filter based on entry for provider number
                }

                if (txtProviderName.Text.Trim() != string.Empty && (dt != null || dt.Rows.Count > 0))
                {
                    if ((dt.Select("providerName like '%" + txtProviderName.Text + "%'").Length > 0))
                    {
                        dt = dt.Select("providerName like '%" + txtProviderName.Text + "%'").CopyToDataTable(); // filter based on the entry for provider name
                    }
                    else
                    {
                        dt = null;
                    }
                }
                if (txtZip.Text.Trim() != string.Empty && (dt != null || dt.Rows.Count > 0) )
                {
                    if ((dt.Select("providerZip like '%" + txtZip.Text + "%'")).Length > 0)
                    {
                        dt = dt.Select("providerZip like '%" + txtZip.Text + "%'").CopyToDataTable(); // filter based on the entry for zip
                    }
                    else
                    {
                        dt = null;
                    }
                }

                int totalRows = 0;  
                if (dt != null)
                {
                    totalRows = dt.Rows.Count;
                    DataView dv = new DataView(dt)  // create dataview for sorting
                    {
                        Sort = Session["sortText"].ToString() // sort per new/last request 
                    };
                    DataTable dtSorted = dv.ToTable(); // convert dataview back to datatable

                    gvProvider.DataSource = dtSorted.AsEnumerable().Skip((pageNumber - 1) * pageSize).Take(pageSize).CopyToDataTable(); // select rows based for the current page
                }
                else
                {
                    gvProvider.DataSource = dt;

                }
                gvProvider.DataBind();
                DisplayPaging(totalRows, pageNumber, pageSize); // calculate and display page numbers at the bottom of the gridview 


            }
            catch (Exception ex)
            {
                WriteErrorLog(ex, filePath, fileName); // Method for Error Logging region
            }
        }

        private void DisplayPaging(int totalRows, int pageNumber, int pageSize)
        {
            try
            {
                int totalPages = totalRows / pageSize;

                if ((totalRows % pageSize) > 0) ++totalPages;

                lblTotalPages.Text = "Page " + pageNumber.ToString() + " of " + totalPages.ToString();
                SetPageNumbers(pageNumber, totalPages);
            }
            catch (Exception ex)
            {
                WriteErrorLog(ex, filePath, fileName);
            }

        }

        private void SetPageNumbers(int pageNumber, int totalPages)
        {
            List<ListItem> pages = new List<ListItem>();

            if (totalPages > 0)
            {
                int startButtonPage = pageNumber;
                int endButtonPage = totalPages;

                if (totalPages <= 10) { startButtonPage = 1; }
                else if ((startButtonPage + 9) > totalPages) { startButtonPage = totalPages - 10; }

                if (totalPages > (startButtonPage + 10)) endButtonPage = startButtonPage + 10;

                if (startButtonPage > 1 && totalPages > 10)
                {
                    pages.Add(new ListItem("Prev", (startButtonPage - 1).ToString(), (startButtonPage - 1) != (pageNumber))); // Add prev page link button
                }

                for (int i = startButtonPage; i <= endButtonPage; i++) //Add page number link buttons
                {
                    pages.Add(new ListItem(i.ToString(), i.ToString(), i != (pageNumber)));
                }

                if (endButtonPage < totalPages) // Add next page link button
                {
                    pages.Add(new ListItem("Next", (endButtonPage + 1).ToString(), (endButtonPage + 1) != (pageNumber)));
                }

                rptrPaging.DataSource = pages;

            }
            else
            {
                rptrPaging.DataSource = null;
                lblTotalPages.Text = string.Empty;

            }
            rptrPaging.DataBind();
        }

        protected void BtnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (Cache["Provider"] == null)
                {
                    InitializeSessionVariables();
                    ImportProviderData();
                }
                DataTable dt = (DataTable)Cache["Provider"];
                string attachment = "attachment; filename=log.xls";
                Response.ClearContent();
                Response.AddHeader("content-disposition", attachment);
                Response.ContentType = "application/vnd.ms-excel";
                string tab = "";
                foreach (DataColumn dc in dt.Columns)
                {
                    Response.Write(tab + dc.ColumnName);
                    tab = "\t";
                }
                Response.Write("\n");
                int i;
                foreach (DataRow dr in dt.Rows)
                {
                    tab = "";
                    for (i = 0; i < dt.Columns.Count; i++)
                    {
                        Response.Write(tab + dr[i].ToString());
                        tab = "\t";
                    }
                    Response.Write("\n");
                }
                Response.End();
            }
            catch(Exception ex)
            {
                WriteErrorLog(ex, filePath, fileName);
            }
        }

        #endregion

        #region GridView Control Events
        protected void LnkPageIndex_Click(object sender, EventArgs e)
        {
            try
            {
                int pageNumber = int.Parse((sender as LinkButton).CommandArgument);
                Session["currentPageNumber"] = pageNumber;
                PopulateGrid(pageNumber, int.Parse(ddlPageRows.SelectedValue.ToString())); // Methods for gridview region
            }
            catch (Exception ex)
            {
                WriteErrorLog(ex, filePath, fileName);
            }

        }

        protected void DDLPageRows_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int pageNumber = int.Parse(Session["currentPageNumber"].ToString());
                int pageSize = int.Parse(ddlPageRows.SelectedValue.ToString());
                PopulateGrid(pageNumber, pageSize);  // Methods for Gridview region
            }
            catch (Exception ex)
            {
                WriteErrorLog(ex, filePath, fileName); // Method in Error Logging region
            }

        }

        protected void BtnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if ((sender as Button).Text == "Refresh")
                {
                    txtProviderName.Text = string.Empty;
                    txtProviderNumber.Text = string.Empty;
                    txtZip.Text = string.Empty;
                    InitializeSessionVariables(); // Methods for Page Load Events Region
                }
                PopulateGrid(1, int.Parse(ddlPageRows.SelectedValue.ToString())); // Method in Error Logging region
            }
            catch (Exception ex)
            {
                WriteErrorLog(ex, filePath, fileName);  // Method in Error Logging regio
            }
        }

        #endregion

        #region Error Logging
        private static void WriteErrorLog(Exception ex, string filePath, string fileName)
        {
            try
            {
                ErrorLog errorLog = new ErrorLog();
                errorLog.LogError(ex, filePath, fileName); // Provider Library Log Helper
            }
            catch { }
        }
        #endregion
    }
}


