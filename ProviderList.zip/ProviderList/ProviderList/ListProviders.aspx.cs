﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using ProviderLibrary.DataHelper; // for data retrieval
using ProviderLibrary.LogHelper; // for error logging

namespace ProviderList
{
    public partial class ListProviders : System.Web.UI.Page
    {
        #region Fields
        string _filePath, _fileName, _externalUrl, _token, _providerType = string.Empty;
        #endregion

        #region Page Load Event
        protected void Page_Load(object sender, EventArgs e)
        {
            // get info from the web.config
            GetConfigFileInfo(); // Methods for page load event region

            if (!IsPostBack || Cache["Provider"] == null) // if first time or the cached object doesn't exist, then get the external data
            {
                InitializeSessionVariables();
                ImportProviderData(); // get external data region
                PopulateGrid(1, 15); // methods for GridView region
            }
        }


        #endregion

        #region Methods for Page load event
        private void GetConfigFileInfo()
        {
            try
            {
                _filePath = ConfigurationManager.AppSettings["ErrorLogDirectory"];
                _fileName = ConfigurationManager.AppSettings["ProviderListErrorFile"];
                _externalUrl = ConfigurationManager.AppSettings["ExternalUrl"];
                _token = ConfigurationManager.AppSettings["Token"];
                _providerType = ConfigurationManager.AppSettings["ProviderType"];

            }
            catch
            {
                // ignored
            }
        }
        private void InitializeSessionVariables()
        {
            Session["sortText"] = "providerNumber ASC";
            Session["currentPageNumber"] = "1";
        }
        #endregion

        #region Get external Data
        private void ImportProviderData()
        {
            try
            {
                ExternalData externalData = new ExternalData();
                var dt = externalData.GetExternalData(_externalUrl, _token, _providerType, _filePath, _fileName);
                Cache["Provider"] = dt; // cache the datatable for subsequent use
            }
            catch (Exception ex)
            {
                WriteErrorLog(ex, _filePath, _fileName);
            }

        }
        #endregion

        #region GridView Events
        protected void GvProvider_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                GetSortColumnAndDirection(gvProvider, e); // get selected column for sorting and sorting direction - Methods for Gridview region

                PopulateGrid(int.Parse(Session["currentPageNumber"].ToString()), int.Parse(ddlPageRows.SelectedValue)); // Methods for GridView region
            }
            catch (Exception ex)
            {
                WriteErrorLog(ex, _filePath, _fileName);  // Method for Error Logging region
            }

        }
        #endregion

        #region Methods for GridView
        private void GetSortColumnAndDirection(GridView gv, GridViewSortEventArgs e) // get selected colum and sorting order
        {
            try
            {
                string sField = e.SortExpression;
                SortDirection sDirection = e.SortDirection;

                if (gv.Attributes["CurrentSortField"] != null && gv.Attributes["CurrentSortDirection"] != null)
                {

                    if (sField == gv.Attributes["CurrentSortField"])
                    {
                        sDirection = gv.Attributes["CurrentSortDirection"] == "ASC" ? SortDirection.Descending : SortDirection.Ascending;
                    }
                    gv.Attributes["CurrentSortField"] = sField;
                    gv.Attributes["CurrentSortDirection"] = (sDirection == SortDirection.Ascending ? "ASC" : "DESC");
                    string strSortDirection = sDirection == SortDirection.Ascending ? "ASC" : "DESC";

                    // store the selected column for sort and the sort direction in the session varaible for  a 
                    Session["sorttext"] = sField + " " + strSortDirection;
                }
            }
            catch (Exception ex)
            {
                WriteErrorLog(ex, _filePath, _fileName); // Method in Error Logging region
            }

        }

        private void PopulateGrid(int pageNumber, int pageSize)
        {
            try
            {
                DataTable dt = (DataTable)Cache["Provider"];

                if (txtProviderNumber.Text.Trim() != string.Empty)
                {
                    dt = dt.Select("providerNumber like '%" + txtProviderNumber.Text + "%'").CopyToDataTable(); //filter based on entry for provider number
                }

                if (dt != null && (txtProviderName.Text.Trim() != string.Empty))
                {
                    dt = (dt.Select("providerName like '%" + txtProviderName.Text + "%'").Length > 0) ? dt.Select("providerName like '%" + txtProviderName.Text + "%'").CopyToDataTable() : null;
                }
                if (dt != null && (txtZip.Text.Trim() != string.Empty) )
                {
                    dt = (dt.Select("providerZip like '%" + txtZip.Text + "%'")).Length > 0 ? dt.Select("providerZip like '%" + txtZip.Text + "%'").CopyToDataTable() : null;
                }

                int totalRows = 0;  
                if (dt != null)
                {
                    totalRows = dt.Rows.Count;
                    DataView dv = new DataView(dt)  // create dataview for sorting
                    {
                        Sort = Session["sortText"].ToString() // sort per new/last request 
                    };
                    DataTable dtSorted = dv.ToTable(); // convert dataview back to datatable

                    gvProvider.DataSource = dtSorted.AsEnumerable().Skip((pageNumber - 1) * pageSize).Take(pageSize).CopyToDataTable(); // select rows based for the current page
                }
                else
                {
                    gvProvider.DataSource = null;

                }
                gvProvider.DataBind();
                DisplayPaging(totalRows, pageNumber, pageSize); // calculate and display page numbers at the bottom of the gridview 


            }
            catch (Exception ex)
            {
                WriteErrorLog(ex, _filePath, _fileName); // Method for Error Logging region
            }
        }

        private void DisplayPaging(int totalRows, int pageNumber, int pageSize)
        {
            try
            {
                int totalPages = totalRows / pageSize;

                if ((totalRows % pageSize) > 0) ++totalPages;

                lblTotalPages.Text = "Page " + pageNumber.ToString() + " of " + totalPages.ToString();
                SetPageNumbers(pageNumber, totalPages);
            }
            catch (Exception ex)
            {
                WriteErrorLog(ex, _filePath, _fileName);
            }

        }

        private void SetPageNumbers(int pageNumber, int totalPages)
        {
            List<ListItem> pages = new List<ListItem>();

            if (totalPages > 0)
            {
                int startButtonPage = pageNumber;
                int endButtonPage = totalPages;

                if (totalPages <= 10) { startButtonPage = 1; }
                else if ((startButtonPage + 9) > totalPages) { startButtonPage = totalPages - 10; }

                if (totalPages > (startButtonPage + 10)) endButtonPage = startButtonPage + 10;

                if (startButtonPage > 1 && totalPages > 10)
                {
                    pages.Add(new ListItem("Prev", (startButtonPage - 1).ToString(), (startButtonPage - 1) != (pageNumber))); // Add prev page link button
                }

                for (int i = startButtonPage; i <= endButtonPage; i++) //Add page number link buttons
                {
                    pages.Add(new ListItem(i.ToString(), i.ToString(), i != (pageNumber)));
                }

                if (endButtonPage < totalPages) // Add next page link button
                {
                    pages.Add(new ListItem("Next", (endButtonPage + 1).ToString(), (endButtonPage + 1) != (pageNumber)));
                }

                rptrPaging.DataSource = pages;

            }
            else
            {
                rptrPaging.DataSource = null;
                lblTotalPages.Text = string.Empty;

            }
            rptrPaging.DataBind();
        }

        protected void BtnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (Cache["Provider"] == null)
                {
                    InitializeSessionVariables();
                    ImportProviderData();
                }
                DataTable dt = (DataTable)Cache["Provider"];
                string attachment = "attachment; filename=log.xls";
                Response.ClearContent();
                Response.AddHeader("content-disposition", attachment);
                Response.ContentType = "application/vnd.ms-excel";
                string tab = "";
                if (dt != null)
                {
                    foreach (DataColumn dc in dt.Columns)
                    {
                        Response.Write(tab + dc.ColumnName);
                        tab = "\t";
                    }
                    Response.Write("\n");
               
                    foreach (DataRow dr in dt.Rows)
                    {
                        tab = "";
                        for (int i = 0; i < dt.Columns.Count; i++)
                        {
                            Response.Write(tab + dr[i]);
                            tab = "\t";
                        }
                        Response.Write("\n");
                    }
                }
                Response.End();
            }
            catch(Exception ex)
            {
                WriteErrorLog(ex, _filePath, _fileName);
            }
        }

        #endregion

        #region GridView Control Events
        protected void LnkPageIndex_Click(object sender, EventArgs e)
        {
            try
            {
                var linkButton = sender as LinkButton;
                if (linkButton != null)
                {
                    int pageNumber = int.Parse(linkButton.CommandArgument);
                    Session["currentPageNumber"] = pageNumber;
                    PopulateGrid(pageNumber, int.Parse(ddlPageRows.SelectedValue)); // Methods for gridview region
                }
            }
            catch (Exception ex)
            {
                WriteErrorLog(ex, _filePath, _fileName);
            }

        }

        protected void DDLPageRows_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int pageNumber = int.Parse(Session["currentPageNumber"].ToString());
                int pageSize = int.Parse(ddlPageRows.SelectedValue);
                PopulateGrid(pageNumber, pageSize);  // Methods for Gridview region
            }
            catch (Exception ex)
            {
                WriteErrorLog(ex, _filePath, _fileName); // Method in Error Logging region
            }

        }

        protected void BtnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                var button = sender as Button;
                if (button != null && button.Text == "Refresh")
                {
                    txtProviderName.Text = string.Empty;
                    txtProviderNumber.Text = string.Empty;
                    txtZip.Text = string.Empty;
                    InitializeSessionVariables(); // Methods for Page Load Events Region
                }
                PopulateGrid(1, int.Parse(ddlPageRows.SelectedValue)); // Method in Error Logging region
            }
            catch (Exception ex)
            {
                WriteErrorLog(ex, _filePath, _fileName);  // Method in Error Logging regio
            }
        }

        #endregion

        #region Error Logging
        private static void WriteErrorLog(Exception ex, string filePath, string fileName)
        {
            try
            {
                ErrorLog errorLog = new ErrorLog();
                errorLog.LogError(ex, filePath, fileName); // Provider Library Log Helper
            }
            catch
            {
                // ignored
            }
        }
        #endregion
    }
}


