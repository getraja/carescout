﻿namespace ProviderList
{
    internal class CreateHtmlTextWriter
    {
    }
}